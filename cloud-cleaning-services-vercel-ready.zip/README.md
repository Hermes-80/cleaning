# Cloud Cleaning Services

Static one-page website for Cloud Cleaning Services in Austin / Central Texas.

## Deploy to Vercel

1. Push this repo to GitHub.
2. Go to https://vercel.com/new
3. Import the GitHub repository.
4. Framework Preset: **Other**
5. Build Command: leave blank
6. Output Directory: leave blank or `.`
7. Click **Deploy**

Because this project is a static `index.html` site, Vercel can deploy it directly from the repository root.
